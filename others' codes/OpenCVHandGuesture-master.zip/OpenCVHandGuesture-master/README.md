OpenCVHandGuesture
==================

Hand Tracking And Gesture Detection (OpenCV)
To get an understanding of how it works,
please visit http://s-ln.in/2013/04/18/hand-tracking-and-gesture-detection-opencv/
